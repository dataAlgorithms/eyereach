#!/usr/bin/python

import os
import re 

httpHead = '''

    server {
        listen 8080;
        server_name flv.%s.follow302;
    
        proxy_intercept_errors on;
        recursive_error_pages on;
        location  / {
            set $user_host $arg_cchost;
    
            if ($query_string ~* "cchost=[^&]+&?(.*)(ratio=\d+.*)&interclient=[^&]+") {
                set $user_args $1$2;
                rewrite ^(.*)_\d+\.flv$ $1.flv?$user_args? break;
            }
    
            if ($query_string ~* "cchost=[^&]+&?(.*)&interclient=[^&]+") {
                set $user_args $1;
                rewrite ^ $uri?$user_args? break;
            }
    
            access_by_lua '
                print("======== pull from source ======= " .. ngx.var.request_uri)
                print(ngx.req.raw_header())
                print("=================================")
            ';
            proxy_pass http://$user_host;
            proxy_set_header Host $user_host;
            error_page 302 = @error_page_302;
        }
        location ~ /proxyto/([^/]+)(.*) {
            proxy_pass http://$1$2$is_args$query_string;
            error_page 302 = @error_page_302;
        }
        location @error_page_302 {
            rewrite_by_lua '
                local _, _, upstream_http_location = string.find(ngx.var.upstream_http_location, "^http:/(.*)$")
                ngx.header["cnkedao"] = "/proxyto" .. upstream_http_location
                ngx.exec("/proxyto" .. upstream_http_location);
            ';
        }
    }
    
    upstream flv.%s.follow302.8080 {
        server  127.0.0.1:8080;
        localfirst;
        #keepalive 1024;
    }

'''

http = '''

    server {
        listen 80;
        server_name %s;

        location ~* \.flv$ {
            if ($arg_cchost) {
                break;
            }
            if ($arg_ratio) {
                rewrite ^(.*).flv$ $1_$arg_ratio.flv?cchost=$host last;
            }
            if ($arg_ratio = "") {
                rewrite ^(.*).flv$ $1.flv?cchost=$host last;
            }

            http_live on;
 
            gop_enable on;
            gop_min 250;
            zero_timestamp on;
            
            stream_type live_flv;
            
            live_proxy_connect_timeout 10s;
            live_proxy_http_version 1.1;
            live_proxy_ignore_client_abort off;
            live_proxy_next_upstream error timeout invalid_header http_500 http_502 http_503 http_504 http_403 http_404;
            add_header Cache-Control no-cache;
            add_header Content-Type video/x-flv;
            add_header Access-Control-Allow-Origin *;
            add_header Server "";
            live_proxy_pass http://flv.%s.follow302.8080;
            live_proxy_set_header Host flv.%s.follow302;
        }
    }

    #############http end##########################
'''

def httpConfig(sUrls, csName):

    if sUrls is None:
        return
    lUrls = re.split("\s+", sUrls)
    lUrls = [i for i in lUrls if not len(i) == 0]
    sUrls = ' '.join(lUrls)

    config = http % (sUrls, csName, csName)
    ng.write('%s%s' % (config, os.linesep))
    

if __name__ == "__main__":

    import sys

    if len(sys.argv) < 2:
       print("You should input cs name, eg, shihou!") 
       sys.exit(0)

    csName = sys.argv[1]

    sUrls = '''
qhdl.shihoutv.com
chdl.shihoutv.com

    '''

    ng = open('http_%s.conf' % csName, 'w')

    # wrte http header 
    ng.write(httpHead % (csName, csName))

    # write http
    httpConfig(sUrls, csName)

    # close
    ng.close()
