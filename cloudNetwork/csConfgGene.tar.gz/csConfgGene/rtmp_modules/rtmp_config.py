#!/usr/bin/python

import os
import re 

rtmpHead = '''

'''

rtmp = '''
    server {
        listen 1935;
        server_name %s;      #vhost name
        timeout 10s;

        zero_timestamp on;        #timestamp reset switch
        gop_enable on;            #gop switch

        playagain_as_stoppause on;
        ignore_closestream    on;
        swf_check off;                       #off means swf check disable 
        swf_path /usr/local/sms_bak/swf/;    #directory where swf file stores
        swf_interval 60;                     #the time interval judge swf file update

        default_app on;

        application sms_default_app {
            pull local;
            live on;
            idle_streams on;
            idle_streams_timeout 30s;
            pull rtmp://%s dynamic;
            push rtmp://%s dynamic;
        }       
    }
'''

def rtmpConfig(sUrls):

    if sUrls is None:
        return

    lUrls = re.split("\s+", sUrls)

    configs = ""

    for url in lUrls:
        if len(url) == 0:
            continue
        config = rtmp % (url, url, url)
        ng.write('%s%s' % (config, os.linesep))
        configs += config

if __name__ == "__main__":
    sUrls = '''
qhdl.shihoutv.com
chdl.shihoutv.com

    '''

    import sys

    if len(sys.argv) < 2:
       print("You should input cs name, eg, shihou!")
       sys.exit(0)

    csName = sys.argv[1]

    ng = open('rtmp_%s.conf' % csName, 'w')

    # write rtmp header
    ng.write(rtmpHead)

    # wrtie rtmp
    rtmpConfig(sUrls)

    # close
    ng.close()
